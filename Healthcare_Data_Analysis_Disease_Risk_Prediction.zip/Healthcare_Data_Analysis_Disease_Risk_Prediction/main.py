import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay

# Educational demo only: synthetic data, not a medical diagnostic tool.
os.makedirs("output", exist_ok=True)
df = pd.read_csv("dataset/healthcare_data.csv")

print("\\n=== Healthcare Data Analysis for Disease Risk Prediction ===")
print("\\nFirst five rows:")
print(df.head())
print("\\nDataset shape:", df.shape)
print("\\nMissing values:")
print(df.isnull().sum())
print("\\nSummary statistics:")
print(df.describe().round(2))

# Disease-label distribution
df["Disease"].value_counts().sort_index().plot(kind="bar")
plt.title("Synthetic Disease Label Distribution")
plt.xlabel("Disease label (0 or 1)")
plt.ylabel("Number of records")
plt.tight_layout()
plt.savefig("output/disease_distribution.png", dpi=150)
plt.close()

# Age distribution
sns.histplot(data=df, x="Age", hue="Disease", bins=12, multiple="stack")
plt.title("Age Distribution by Synthetic Label")
plt.tight_layout()
plt.savefig("output/age_analysis.png", dpi=150)
plt.close()

# Correlation heatmap
plt.figure(figsize=(8, 6))
sns.heatmap(df.corr(numeric_only=True), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Healthcare Dataset Correlation Heatmap")
plt.tight_layout()
plt.savefig("output/correlation_heatmap.png", dpi=150)
plt.close()

# Machine learning demonstration
X = df.drop(columns=["Disease"])
y = df["Disease"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
model = RandomForestClassifier(n_estimators=150, random_state=42, class_weight="balanced")
model.fit(X_train, y_train)
pred = model.predict(X_test)

print("\\n=== Demo Model Evaluation ===")
print("Accuracy:", round(accuracy_score(y_test, pred) * 100, 2), "%")
print("\\nClassification report:")
print(classification_report(y_test, pred, zero_division=0))

disp = ConfusionMatrixDisplay.from_predictions(y_test, pred)
disp.ax_.set_title("Demo Model Confusion Matrix")
plt.tight_layout()
plt.savefig("output/confusion_matrix.png", dpi=150)
plt.close()

sample = pd.DataFrame([{
    "Age": 40, "BMI": 26.0, "BloodPressure": 125, "Glucose": 110,
    "Smoking": 0, "PhysicalActivity": 1
}])
label = int(model.predict(sample)[0])
print("\\nExample input:", sample.to_dict(orient="records")[0])
print("Predicted demo label:", label)
print("0/1 is a synthetic dataset label, NOT a clinical diagnosis.")
print("\\nCharts saved in the output/ folder.")
