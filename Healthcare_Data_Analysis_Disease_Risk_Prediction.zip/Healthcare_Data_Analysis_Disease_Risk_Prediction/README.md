# Healthcare Data Analysis for Disease Risk Prediction

## Project Overview
This beginner-friendly Python project explores a **synthetic healthcare dataset** and demonstrates data visualization and a Random Forest classification workflow.

## Objectives
- Inspect healthcare-style data and summary statistics.
- Check missing values.
- Visualize synthetic label distribution and age distribution.
- Explore correlations between features.
- Demonstrate train/test splitting and model evaluation.

## Dataset
`dataset/healthcare_data.csv` contains 300 synthetic records and these columns:
- `Age`: age in years
- `BMI`: body mass index value
- `BloodPressure`: illustrative blood pressure value
- `Glucose`: illustrative glucose value
- `Smoking`: 0 = no, 1 = yes
- `PhysicalActivity`: 0 = low/not active, 1 = active
- `Disease`: synthetic binary label used only for this demonstration

**Important:** The dataset and labels are artificially generated for learning. They do not represent real patients and must not be used for diagnosis, treatment, or health decisions.

## Folder Structure
```text
Healthcare_Data_Analysis_Disease_Risk_Prediction/
├── dataset/
│   └── healthcare_data.csv
├── output/
│   ├── age_analysis.png
│   ├── confusion_matrix.png
│   ├── correlation_heatmap.png
│   └── disease_distribution.png
├── main.py
├── requirements.txt
└── README.md
```

## How to Run in VS Code
1. Install Python 3.
2. Open this folder in VS Code.
3. Open Terminal → New Terminal.
4. Install libraries:
   ```bash
   pip install -r requirements.txt
   ```
5. Run:
   ```bash
   python main.py
   ```

The program prints data summaries and model evaluation in the terminal, and saves charts in `output/`.

## Example Run Results
- Dataset records: 300
- Dataset columns: 7
- Demonstration model accuracy on the held-out test split: 98.67%
- Example synthetic input predicted label: 0

These metrics describe only this generated sample dataset. They do not establish real-world medical prediction performance.

## Tools Used
Python, Pandas, NumPy, Matplotlib, Seaborn, Scikit-learn, VS Code, GitHub.
